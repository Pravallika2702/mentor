package com.example.mentor;

import org.springframework.data.jpa.repository.JpaRepository;

public interface FacultyInterface extends JpaRepository<Faculty, Long> {
}