package com.example.mentor;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/faculty")
public class FacultyController {

    @Autowired
    private FacultyInterface facinterface;

    @Autowired
    private StudentInterface stuinterface;

    @PostMapping("/add")
    public Faculty addFaculty(@RequestBody Faculty faculty) {
        return facinterface.save(faculty);
    }

    @GetMapping("/get")
    public List<Faculty> getAllFaculties() {
        return facinterface.findAll();
    }

    @PostMapping("/addStudents/{facultyId}")
    public Faculty addStudentsToFaculty(@PathVariable Long facultyId, @RequestBody List<Long> studentIds) {
        Faculty faculty = facinterface.findById(facultyId).orElse(null);
        if (faculty != null) {
            List<Student> students = faculty.getStudents();
            for (Long id : studentIds) {
                Student student = stuinterface.findById(id).orElse(null);
                if (student != null) {
                    student.setFaculty(faculty);
                    students.add(student);
                }
            }
            faculty.setStudents(students);
            return facinterface.save(faculty);
        } else {
            return null;
        }
    }

    @GetMapping("/students/{facultyId}")
    public List<Student> getStudentsByFaculty(@PathVariable Long facultyId) {
        Faculty faculty = facinterface.findById(facultyId).orElse(null);
        if (faculty != null) {
            return faculty.getStudents();
        } else {
            return null;
        }
    }

    @GetMapping("/faculties-with-students")
    public List<Faculty> getFacultiesWithStudents() {
        return facinterface.findAll();
    }
}