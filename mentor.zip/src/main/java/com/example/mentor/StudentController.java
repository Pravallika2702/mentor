package com.example.mentor;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/student")
public class StudentController {

    @Autowired
    private StudentInterface stuinterface;

    @PostMapping("/add")
    public Student addStudent(@RequestBody Student student) {
        return stuinterface.save(student);
    }

    @GetMapping("/get")
    public List<Student> getAllStudents() {
        return stuinterface.findAll();
    }

    @GetMapping("/get/{id}")
    public Student getStudentById(@PathVariable Long id) {
        return stuinterface.findById(id).orElse(null);
    }

    @PutMapping("/put/{id}")
    public Student updateStudent(@PathVariable Long id, @RequestBody Student student) {
        return stuinterface.findById(id).map(existingStudent -> {
            existingStudent.setName(student.getName());
            existingStudent.setAdd(student.getAdd());
            return stuinterface.save(existingStudent);
        }).orElse(null);
    }

    @DeleteMapping("/delete/{id}")
    public String deleteStudent(@PathVariable Long id) {
        if (stuinterface.existsById(id)) {
        	stuinterface.deleteById(id);
            return "Student deleted successfully";
        } else {
            return "Student not found";
        }
    }
}