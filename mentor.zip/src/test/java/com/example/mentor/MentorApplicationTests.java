package com.example.mentor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MentorApplicationTests {

	@Test
	void contextLoads() {
	}

}
